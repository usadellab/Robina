### Name: amplicon.plot
### Title: Create an amplicon plot
### Aliases: amplicon.plot
### Keywords: hplot

### ** Examples

  ##none yet; takes too long



