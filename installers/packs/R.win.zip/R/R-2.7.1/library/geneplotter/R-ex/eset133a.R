### Name: expressionSet133a
### Title: A small dataset for testing
### Aliases: expressionSet133a
### Keywords: datasets

### ** Examples

data(expressionSet133a)



