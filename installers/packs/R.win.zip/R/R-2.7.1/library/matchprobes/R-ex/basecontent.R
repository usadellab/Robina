### Name: basecontent
### Title: Obtain the ATCG content of a gene
### Aliases: basecontent countbases
### Keywords: manip

### ** Examples

 v<-c("AAACT", "GGGTT", "ggAtT")
 basecontent(v)

 countbases(v)



