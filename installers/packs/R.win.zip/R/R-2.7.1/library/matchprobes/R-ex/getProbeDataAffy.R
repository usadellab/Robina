### Name: getProbeDataAffy
### Title: Read a data file describing the probe sequences on an Affymetrix
###   genechip
### Aliases: getProbeDataAffy
### Keywords: IO utilities

### ** Examples

  ## Please refer to the vignette



