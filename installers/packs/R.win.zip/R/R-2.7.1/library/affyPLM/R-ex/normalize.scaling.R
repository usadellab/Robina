### Name: normalize.scaling
### Title: Scaling normalization
### Aliases: normalize.scaling normalize.AffyBatch.scaling
### Keywords: manip

### ** Examples

data(affybatch.example)
normalize.AffyBatch.scaling(affybatch.example)



