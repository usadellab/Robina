### Name: preprocess
### Title: Background correct and Normalize
### Aliases: preprocess
### Keywords: manip

### ** Examples

data(affybatch.example)

# should be equivalent to the bg and norm of rma()
abatch.preprocessed <- preprocess(affybatch.example)




