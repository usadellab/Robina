### Name: threestepPLM
### Title: Three Step expression measures returned as a PLMset
### Aliases: threestepPLM
### Keywords: manip

### ** Examples

data(affybatch.example)

# should be equivalent to rma()
## Not run: eset <- threestepPLM(affybatch.example)



