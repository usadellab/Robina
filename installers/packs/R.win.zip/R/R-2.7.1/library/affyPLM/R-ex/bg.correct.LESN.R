### Name: bg.correct.LESN
### Title: LESN - Low End Signal is Noise Background corrections
### Aliases: bg.correct.LESN
### Keywords: manip

### ** Examples

data(affybatch.example)
affybatch.example.bgcorrect <- bg.correct.LESN(affybatch.example)



