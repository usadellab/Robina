### Name: titlePage
### Title: QC report title page with array names
### Aliases: titlePage QCReport-titlePage
### Keywords: hplot

### ** Examples

     
    library(affydata)
    data(Dilution)
    
   titlePage(Dilution)




