### Name: correlationPlot
### Title: Array-array intensity correlation plot
### Aliases: correlationPlot QCReport-correlationPlot
### Keywords: hplot

### ** Examples


   library(affydata)
    
   data(Dilution)

  correlationPlot(Dilution)




