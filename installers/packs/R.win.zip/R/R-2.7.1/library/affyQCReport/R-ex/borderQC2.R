### Name: borderQC2
### Title: Center of intensity QC plots
### Aliases: borderQC2
### Keywords: hplot

### ** Examples


   library(affydata)
    data(Dilution)

   borderQC2(Dilution)




