### Name: borderQC1
### Title: Distribution of intensities of the border elements
### Aliases: borderQC1
### Keywords: hplot

### ** Examples

    
    library(affydata)
    data(Dilution)

   borderQC1(Dilution)




