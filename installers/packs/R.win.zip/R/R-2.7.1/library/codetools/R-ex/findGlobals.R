### Name: findGlobals
### Title: Find Global Functions and Variables Used by a Closure
### Aliases: findGlobals
### Keywords: programming

### ** Examples

findGlobals(findGlobals)
findGlobals(findGlobals, merge = FALSE)



