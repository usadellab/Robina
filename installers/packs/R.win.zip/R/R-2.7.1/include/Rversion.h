/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 132865
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "2"
#define R_MINOR  "7.1"
#define R_STATUS ""
#define R_YEAR   "2008"
#define R_MONTH  "06"
#define R_DAY    "23"
#define R_SVN_REVISION "45970"
#define R_FILEVERSION    2,71,45970,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
