void rma_bg_parameters(double *PM,double *param, int rows, int cols, int column);
void rma_bg_adjust(double *PM,double *param, int rows, int cols, int column);
void rma_bg_correct(double *PM, int rows, int cols);
