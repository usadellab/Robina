###################################################
### chunk number 1: setup
###################################################
#line 41 "independent_filtering_plots.Rnw"
options( width = 80 )


###################################################
### chunk number 2: libraries
###################################################
#line 83 "independent_filtering_plots.Rnw"
library("genefilter")
library("ALL")
data("ALL")


###################################################
### chunk number 3: sample_data
###################################################
#line 93 "independent_filtering_plots.Rnw"
bcell <- grep("^B", as.character(ALL$BT))
moltyp <- which(as.character(ALL$mol.biol) %in% 
                c("NEG", "BCR/ABL"))
ALL_bcrneg <- ALL[, intersect(bcell, moltyp)]
ALL_bcrneg$mol.biol <- factor(ALL_bcrneg$mol.biol)
n1 <- n2 <- 3
set.seed(1969)
use <- unlist(tapply(1:ncol(ALL_bcrneg), 
                     ALL_bcrneg$mol.biol, sample, n1))
subsample <- ALL_bcrneg[,use]


###################################################
### chunk number 4: stats
###################################################
#line 110 "independent_filtering_plots.Rnw"
S <- rowSds( exprs( subsample ) )
temp <- rowttests( subsample, subsample$mol.biol )
d <- temp$dm
p <- temp$p.value
t <- temp$statistic


###################################################
### chunk number 5: filter_volcano
###################################################
#line 129 "independent_filtering_plots.Rnw"
S_cutoff <- quantile(S, .50)
filter_volcano(d, p, S, n1, n2, alpha=.01, S_cutoff)


###################################################
### chunk number 6: kappa
###################################################
#line 154 "independent_filtering_plots.Rnw"
t <- seq(0, 5, length=100)
plot(t, kappa_t(t, n1, n2) * S_cutoff, 
     xlab="|T|", ylab="Fold change bound", type="l")


###################################################
### chunk number 7: table
###################################################
#line 185 "independent_filtering_plots.Rnw"
table(ALL_bcrneg$mol.biol)


###################################################
### chunk number 8: filtered_p
###################################################
#line 190 "independent_filtering_plots.Rnw"
S2 <- rowVars(exprs(ALL_bcrneg))
p2 <- rowttests(ALL_bcrneg, "mol.biol")$p.value
theta <- seq(0, .5, .1)
p_bh <- filtered_p(S2, p2, theta, method="BH")


###################################################
### chunk number 9: p_bh
###################################################
#line 198 "independent_filtering_plots.Rnw"
head(p_bh)


###################################################
### chunk number 10: rejection_plot
###################################################
#line 209 "independent_filtering_plots.Rnw"
rejection_plot(p_bh, at="sample",
               xlim=c(0,.3), ylim=c(0,1000),
               main="Benjamini & Hochberg adjustment")


###################################################
### chunk number 11: filtered_R
###################################################
#line 228 "independent_filtering_plots.Rnw"
theta <- seq(0, .80, .01)
R_BH <- filtered_R(alpha=.10, S2, p2, theta, method="BH")


###################################################
### chunk number 12: R_BH
###################################################
#line 234 "independent_filtering_plots.Rnw"
head(R_BH)


###################################################
### chunk number 13: filtered_R_plot
###################################################
#line 243 "independent_filtering_plots.Rnw"
plot(theta, R_BH, type="l",
     xlab=expression(theta), ylab="Rejections",
     main="BH cutoff = .10"
     )


###################################################
### chunk number 14: sessionInfo
###################################################
#line 258 "independent_filtering_plots.Rnw"
si <- as.character( toLatex( sessionInfo() ) )
cat( si[ -grep( "Locale", si ) ], sep = "\n" )


