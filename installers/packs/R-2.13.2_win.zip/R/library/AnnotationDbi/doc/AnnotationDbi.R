###################################################
### chunk number 1: <available schemas
###################################################
#line 111 "AnnotationDbi.Rnw"
require(org.Hs.eg.db)
available.dbschemas()


###################################################
### chunk number 2: setup0
###################################################
#line 136 "AnnotationDbi.Rnw"
options(continue=" ", prompt="R> ", width=72L)


###################################################
### chunk number 3: setup
###################################################
#line 140 "AnnotationDbi.Rnw"
library("hgu95av2.db")


###################################################
### chunk number 4: objects
###################################################
#line 146 "AnnotationDbi.Rnw"
ls("package:hgu95av2.db")


###################################################
### chunk number 5: Question #1
###################################################
#line 157 "AnnotationDbi.Rnw"
library("hgu95av2.db")
search()
hgu95av2_dbschema()
org.Hs.eg_dbschema()


###################################################
### chunk number 6: QAlisting
###################################################
#line 169 "AnnotationDbi.Rnw"
qcdata = capture.output(hgu95av2())
head(qcdata, 20)


###################################################
### chunk number 7: mapcounts eval=FALSE
###################################################
## #line 177 "AnnotationDbi.Rnw"
## hgu95av2MAPCOUNTS


###################################################
### chunk number 8: envApiDemo1
###################################################
#line 185 "AnnotationDbi.Rnw"
all_probes <- ls(hgu95av2ENTREZID)
length(all_probes)

set.seed(0xa1beef)
probes <- sample(all_probes, 5)
probes


###################################################
### chunk number 9: envApiDemo2
###################################################
#line 196 "AnnotationDbi.Rnw"
hgu95av2ENTREZID[[probes[1]]]
hgu95av2ENTREZID$"31882_at"

syms <- unlist(mget(probes, hgu95av2SYMBOL))
syms


###################################################
### chunk number 10: helpDemo eval=FALSE
###################################################
## #line 210 "AnnotationDbi.Rnw"
## ?hgu95av2CHRLOC


###################################################
### chunk number 11: Question #2
###################################################
#line 218 "AnnotationDbi.Rnw"
mget(probes, hgu95av2CHRLOC, ifnotfound=NA)[1:2]


###################################################
### chunk number 12: as.list eval=FALSE
###################################################
## #line 239 "AnnotationDbi.Rnw"
## system.time(as.list(hgu95av2SYMBOL)[1:10])
## 
## ## vs:
## 
## system.time(as.list(hgu95av2SYMBOL[1:10]))


###################################################
### chunk number 13: show.revmap
###################################################
#line 260 "AnnotationDbi.Rnw"
unlist(mget(syms, revmap(hgu95av2SYMBOL)))


###################################################
### chunk number 14: thisworks
###################################################
#line 267 "AnnotationDbi.Rnw"
as.list(revmap(hgu95av2PATH)["00300"])


###################################################
### chunk number 15: revmap2
###################################################
#line 274 "AnnotationDbi.Rnw"
x <- hgu95av2PATH
## except for the name, this is exactly revmap(x)
revx <- hgu95av2PATH2PROBE
revx2 <- revmap(x, objName="PATH2PROBE")
revx2
identical(revx, revx2)

as.list(revx["00300"])


###################################################
### chunk number 16: revmap2
###################################################
#line 301 "AnnotationDbi.Rnw"
Term("GO:0000018")
Definition("GO:0000018")


###################################################
### chunk number 17: Question #3
###################################################
#line 313 "AnnotationDbi.Rnw"
rs = ls(revmap(org.Hs.egREFSEQ))[4:6]
EGs = mget(rs, revmap(org.Hs.egREFSEQ), ifnotfound=NA)
##Then get the GO terms.
GOs = mget(unlist(EGs), org.Hs.egGO, ifnotfound=NA)
GOs
##Extract the GOIDs from this list:
GOIDs = unlist(unique(sapply(GOs, names)))
##Then look up what these terms are:
Term(GOIDs)


###################################################
### chunk number 18: toTable
###################################################
#line 335 "AnnotationDbi.Rnw"
head(toTable(hgu95av2GO[probes]))


###################################################
### chunk number 19: undirectedMethod
###################################################
#line 355 "AnnotationDbi.Rnw"
toTable(x)[1:6, ]
toTable(revx)[1:6, ]


###################################################
### chunk number 20: threecols
###################################################
#line 366 "AnnotationDbi.Rnw"
toTable(hgu95av2PFAM)[1:6, ]  # the right values are tagged
as.list(hgu95av2PFAM["1000_at"])


###################################################
### chunk number 21: directedMethods
###################################################
#line 375 "AnnotationDbi.Rnw"
length(x)
length(revx)
allProbeSetIds <- keys(x)
allKEGGIds <- keys(revx)


###################################################
### chunk number 22: moreUndirectedMethods
###################################################
#line 383 "AnnotationDbi.Rnw"
junk <- Lkeys(x)        # same for all maps in hgu95av2.db (except pseudo-map
                        # MAPCOUNTS)
Llength(x)              # nb of Lkeys
junk <- Rkeys(x)        # KEGG ids for PATH/PATH2PROBE maps, GO ids for
                        # GO/GO2PROBE/GO2ALLPROBES maps, etc...
Rlength(x)              # nb of Rkeys


###################################################
### chunk number 23: moreKeysMethods
###################################################
#line 408 "AnnotationDbi.Rnw"
x = hgu95av2ENTREZID[1:10]
## Directed methods
mappedkeys(x)           # mapped keys
count.mappedkeys(x)     # nb of mapped keys
## Undirected methods
mappedLkeys(x)          # mapped left keys
count.mappedLkeys(x)    # nb of mapped Lkeys


###################################################
### chunk number 24: isNA
###################################################
#line 421 "AnnotationDbi.Rnw"
y = hgu95av2ENTREZID[isNA(hgu95av2ENTREZID)]     # usage like is.na()
Lkeys(y)[1:4]


###################################################
### chunk number 25: Question #4
###################################################
#line 434 "AnnotationDbi.Rnw"

count.mappedLkeys(hgu95av2GO)
Llength(hgu95av2GO) - count.mappedLkeys(hgu95av2GO)
mappedLkeys(hgu95av2GO)[1]
toTable(hgu95av2GO["1000_at"])


###################################################
### chunk number 26: revmapUseCases
###################################################
#line 450 "AnnotationDbi.Rnw"
x <- hgu95av2CHR
Rkeys(x)
chroms <- Rkeys(x)[23:24]
chroms
Rkeys(x) <- chroms
toTable(x)


###################################################
### chunk number 27: easy
###################################################
#line 460 "AnnotationDbi.Rnw"
z <- as.list(revmap(x)[chroms])
names(z)
z[["Y"]]


###################################################
### chunk number 28: evilUnlist
###################################################
#line 471 "AnnotationDbi.Rnw"
chrs = c("12","6")
mget(chrs, revmap(hgu95av2CHR[1:30]), ifnotfound=NA)


###################################################
### chunk number 29: evilUnlist2
###################################################
#line 477 "AnnotationDbi.Rnw"
unlist(mget(chrs, revmap(hgu95av2CHR[1:30]), ifnotfound=NA))


###################################################
### chunk number 30: evilUnlist3
###################################################
#line 484 "AnnotationDbi.Rnw"
unlist2(mget(chrs, revmap(hgu95av2CHR[1:30]), ifnotfound=NA))


###################################################
### chunk number 31: cytogenetic2
###################################################
#line 491 "AnnotationDbi.Rnw"
x <- hgu95av2MAP
pbids <- c("38912_at", "41654_at", "907_at", "2053_at", "2054_g_at", 
           "40781_at")
x <- subset(x, Lkeys=pbids, Rkeys="18q11.2")
toTable(x)


###################################################
### chunk number 32: coerce
###################################################
#line 500 "AnnotationDbi.Rnw"
  pb2cyto <- as.character(x)
  pb2cyto[pbids]


###################################################
### chunk number 33: coercWarnings
###################################################
#line 507 "AnnotationDbi.Rnw"
  cyto2pb <- as.character(revmap(x))


###################################################
### chunk number 34: multiProbes
###################################################
#line 532 "AnnotationDbi.Rnw"
  ## How many probes?
  dim(hgu95av2ENTREZID)
  ## Make a mapping with multiple probes exposed 
  multi <- toggleProbes(hgu95av2ENTREZID, "all")
  ## How many probes?
  dim(multi)


###################################################
### chunk number 35: multiProbes2
###################################################
#line 546 "AnnotationDbi.Rnw"
  ## Make a mapping with ONLY multiple probes exposed 
  multiOnly <- toggleProbes(multi, "multiple")
  ## How many probes?
  dim(multiOnly)

  ## Then make a mapping with ONLY single mapping probes
  singleOnly <- toggleProbes(multiOnly, "single")
  ## How many probes?
  dim(singleOnly)  


###################################################
### chunk number 36: multiProbes3
###################################################
#line 562 "AnnotationDbi.Rnw"
  ## Test the multiOnly mapping
  hasMultiProbes(multiOnly)
  hasSingleProbes(multiOnly)

  ## Test the singleOnly mapping
  hasMultiProbes(singleOnly)
  hasSingleProbes(singleOnly)


###################################################
### chunk number 37: orgSchema
###################################################
#line 632 "AnnotationDbi.Rnw"
org.Hs.eg_dbschema() 


###################################################
### chunk number 38: connObj
###################################################
#line 640 "AnnotationDbi.Rnw"
org.Hs.eg_dbconn()


###################################################
### chunk number 39: connObj
###################################################
#line 646 "AnnotationDbi.Rnw"
query <- "SELECT gene_id FROM genes LIMIT 10;"
result = dbGetQuery(org.Hs.eg_dbconn(), query)
result


###################################################
### chunk number 40: Question #5
###################################################
#line 658 "AnnotationDbi.Rnw"
sql <- "SELECT gene_id, chromosome FROM genes AS g, chromosomes AS c WHERE g._id=c._id;"
dbGetQuery(org.Hs.eg_dbconn(),sql)[1:10,]

##OR
toTable(org.Hs.egCHR)[1:10,]


###################################################
### chunk number 41: complexEnv eval=FALSE
###################################################
## #line 687 "AnnotationDbi.Rnw"
## ## Obtain SYMBOLS with at least one GO BP
## ## annotation with evidence IMP, IGI, IPI, or IDA.
## system.time({
## bpids <- eapply(hgu95av2GO, function(x) {
##     if (length(x) == 1 && is.na(x))
##       NA
##     else {
##         sapply(x, function(z) {
##             if (z$Ontology == "BP")
##               z$GOID
##             else
##               NA
##             })
##     }
## })
## bpids <- unlist(bpids)
## bpids <- unique(bpids[!is.na(bpids)])
## g2p <- mget(bpids, hgu95av2GO2PROBE)
## wantedp <- lapply(g2p, function(x) {
##     x[names(x) %in% c("IMP", "IGI", "IPI", "IDA")]
## })
## wantedp <- wantedp[sapply(wantedp, length) > 0]
## wantedp <- unique(unlist(wantedp))
## ans <- unlist(mget(wantedp, hgu95av2SYMBOL))
## })
## length(ans)
## ans[1:10]


###################################################
### chunk number 42: schema
###################################################
#line 721 "AnnotationDbi.Rnw"
hgu95av2_dbschema() 


###################################################
### chunk number 43: schema2
###################################################
#line 731 "AnnotationDbi.Rnw"
hgu95av2ORGPKG 


###################################################
### chunk number 44: schema3
###################################################
#line 737 "AnnotationDbi.Rnw"
org.Hs.eg_dbschema() 


###################################################
### chunk number 45: hgu95av2_org_join
###################################################
#line 758 "AnnotationDbi.Rnw"
orgDBLoc = system.file("extdata", "org.Hs.eg.sqlite", package="org.Hs.eg.db")
attachSQL = paste("ATTACH '", orgDBLoc, "' AS orgDB;", sep = "")
dbGetQuery(hgu95av2_dbconn(), attachSQL)


###################################################
### chunk number 46: complexDb
###################################################
#line 771 "AnnotationDbi.Rnw"
system.time({
SQL <- "SELECT DISTINCT probe_id,symbol FROM probes, orgDB.gene_info AS gi, orgDB.genes AS g, orgDB.go_bp AS bp WHERE bp._id=g._id AND gi._id=g._id AND probes.gene_id=g.gene_id AND bp.evidence IN ('IPI', 'IDA', 'IMP', 'IGI')"
zz <- dbGetQuery(hgu95av2_dbconn(), SQL)
})
#its a good idea to always DETACH your database when you are finished...
dbGetQuery(hgu95av2_dbconn(), "DETACH orgDB"         )


###################################################
### chunk number 47: Question #6
###################################################
#line 784 "AnnotationDbi.Rnw"
sql <- "SELECT gene_id, start_location, end_location, cytogenetic_location FROM genes AS g, chromosome_locations AS c, cytogenetic_locations AS cy WHERE g._id=c._id AND g._id=cy._id"
dbGetQuery(org.Hs.eg_dbconn(),sql)[1:10,]


###################################################
### chunk number 48: Question #7
###################################################
#line 793 "AnnotationDbi.Rnw"
orgDBLoc = system.file("extdata", "org.Hs.eg.sqlite", package="org.Hs.eg.db")
attachSQL = paste("ATTACH '", orgDBLoc, "' AS orgDB;", sep = "")
dbGetQuery(hgu95av2_dbconn(), attachSQL)

goDBLoc = system.file("extdata", "GO.sqlite", package="GO.db")
attachSQL = paste("ATTACH '", goDBLoc, "' AS goDB;", sep = "")
dbGetQuery(hgu95av2_dbconn(), attachSQL)

SQL <- "SELECT DISTINCT p.probe_id, gi.symbol, gt.go_id, gt.definition  FROM probes AS p, orgDB.gene_info AS gi, orgDB.genes AS g, orgDB.go_bp AS bp, goDB.go_term AS gt  WHERE bp._id=g._id AND gi._id=g._id AND p.gene_id=g.gene_id AND bp.evidence IN ('IPI', 'IDA', 'IMP', 'IGI') AND gt.go_id=bp.go_id"
zz <- dbGetQuery(hgu95av2_dbconn(), SQL)

dbGetQuery(hgu95av2_dbconn(), "DETACH orgDB")
dbGetQuery(hgu95av2_dbconn(), "DETACH goDB")


###################################################
### chunk number 49: SessionInfo
###################################################
#line 814 "AnnotationDbi.Rnw"
sessionInfo()


