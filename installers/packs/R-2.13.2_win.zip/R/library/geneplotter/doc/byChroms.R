###################################################
### chunk number 1: loaddata
###################################################
#line 46 "byChroms.Rnw"

 library("annotate")
 library("hu6800.db")
 lens <- unlist(eapply(hu6800CHR, length))

 table(lens)
 wh2 = mget(names(lens)[lens==2], env = hu6800CHR)

 wh2[1]


###################################################
### chunk number 2: fixdata
###################################################
#line 65 "byChroms.Rnw"
chrs2 <- unlist(eapply(hu6800CHR, function(x) x[1]))
chrs2 <- factor(chrs2)
length(chrs2)
 table(unlist(chrs2))


###################################################
### chunk number 3: strandloc
###################################################
#line 82 "byChroms.Rnw"

 strand <- as.list(hu6800CHRLOC)

 splits <- split(strand, chrs2)
 length(splits)
 names(splits)



###################################################
### chunk number 4: chrloc
###################################################
#line 95 "byChroms.Rnw"

 newChrClass <- buildChromLocation("hu6800")



###################################################
### chunk number 5: cPlot
###################################################
#line 103 "byChroms.Rnw"

  library(geneplotter)

  cPlot(newChrClass)



